var theDate = new Date();
document.write("&copy;" + theDate.getFullYear());
document.write(" - Sesfikile Transportation | Last modified:");
var theModifiedDate = new Date(document.lastModified);
document.write(theModifiedDate.toDateString());