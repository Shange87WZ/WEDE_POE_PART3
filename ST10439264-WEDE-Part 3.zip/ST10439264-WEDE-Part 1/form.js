function validateForm(event) {
    event.preventDefault();

    var nameInput = document.getElementById("name");
    var emailInput = document.getElementById("email");
    var message = document.getElementById("message");

    if (nameInput.ariaValueMax.length < 8){
        alert("Name must be at least 8 characters long.");
        nameInput.focus();
        return false;
    }
    
    if (!emailInput.value.includes("@") && emailInput.includes(".")) {
        alert("Email must contain the '@' symbol.")
        emailInput.focus();
        return false;
    }

    if (messageInput.value.length < 1) {
        alert("Please enter your message.");
        messageInput.focus();
        return false;
    }

    document.getElementById("contactForm").submit();
    document.getElementById("sub-btn").innerHTML ="<h4>Message Recieved!</h4>";
}

function clearFields() {
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("message").value = "";
}
