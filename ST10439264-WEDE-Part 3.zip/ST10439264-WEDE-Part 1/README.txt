PART 3
IMPROVEMENT TO PART 2

HTML:
-Form: Added action="sesfikiletrans@gmail.com" in <form> tag.
-Form: Added clear button next to send button
-Added an enquiry form.

FUNCTIONALITY:
-Added last modified date in Footer of all pages.
-Created form validation that ensures that "Name" is <8 characters. Email 
 is required to have "@" and ".".
-Added button to clear text boxes.

SEO
-Added <meta> tag with description.
-Added images and changed their names to:
#'Instagram.png"
#"facebook.png"
#"twitter.png"
